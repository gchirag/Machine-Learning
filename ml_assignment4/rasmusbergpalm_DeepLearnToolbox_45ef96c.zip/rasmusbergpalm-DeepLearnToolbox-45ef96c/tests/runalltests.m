clear all; close all; clc;
addpath(genpath('../.'))
runtests